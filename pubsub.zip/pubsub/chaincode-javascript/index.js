/*
 * Copyright IBM Corp. All Rights Reserved.
 *
 * SPDX-License-Identifier: Apache-2.0
 */

'use strict';

const pubsub = require('./lib/pubsub');

module.exports.PubSub = pubsub;
module.exports.contracts = [pubsub];
