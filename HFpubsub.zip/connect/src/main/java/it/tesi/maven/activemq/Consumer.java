package it.tesi.maven.activemq;

import java.util.ArrayList;

import javax.jms.Destination;

public class Consumer {
	private String nome;
	private String codice;
	private ArrayList<Destination> destinazioni = new ArrayList<Destination>();
	
	public Consumer(String nome, String codice, ArrayList<Destination> destinazioni) {
		this.nome = nome;
		this.codice = codice;
		this.destinazioni = destinazioni;
	}
	
	public Consumer() {
		// TODO Auto-generated constructor stub
	}

	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public String getCodice() {
		return codice;
	}
	public void setCodice(String codice) {
		this.codice = codice;
	}
	public ArrayList<Destination> getDestinazioni() {
		return destinazioni;
	}
	public void setDestinazioni(ArrayList<Destination> destinazioni) {
		this.destinazioni = destinazioni;
	}
	
	

}
