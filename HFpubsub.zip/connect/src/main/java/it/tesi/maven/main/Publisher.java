package it.tesi.maven.main;

import java.io.IOException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Date;
import java.util.HashMap;
import java.util.UUID;

import javax.jms.Connection;
import javax.jms.ConnectionFactory;
import javax.jms.Destination;
import javax.jms.Message;
import javax.jms.MessageProducer;
import javax.jms.Session;
 
import org.apache.activemq.ActiveMQConnectionFactory;
import org.json.JSONObject;

import org.hyperledger.fabric.gateway.Contract;
import org.hyperledger.fabric.gateway.Gateway;
import org.hyperledger.fabric.gateway.Network;
import org.hyperledger.fabric.gateway.Transaction;
import org.hyperledger.fabric.gateway.Wallet;
import org.hyperledger.fabric.gateway.Wallets;
import org.hyperledger.fabric.gateway.spi.CommitListener;
import org.hyperledger.fabric.gateway.spi.PeerDisconnectEvent;
import org.hyperledger.fabric.sdk.BlockEvent.TransactionEvent;


public class Publisher
{
	public static HashMap<String, Integer> commitMap = new HashMap<String, Integer>();
	private String connectionFilePath;
	private String channelName;
	private String chaincodeName;
	private Gateway.Builder builder;
	
	static {
		System.setProperty("org.hyperledger.fabric.sdk.service_discovery.as_localhost", "true");
	}
	
	public Publisher(String connectionFilePath, String channelName, String chaincodeName) {
		this.connectionFilePath = connectionFilePath;
		this.channelName = channelName;
		this.chaincodeName = chaincodeName;
	}
	
	public void fabricConnect(String walletPath, String idFile) throws IOException {
		Path walletDirectory = Paths.get(walletPath);
        Wallet wallet = Wallets.newFileSystemWallet(walletDirectory);
        Path networkConfigFile = Paths.get(connectionFilePath);
        this.builder = Gateway.createBuilder()
        		.identity(wallet, idFile)
        		.networkConfig(networkConfigFile)
        		.discovery(true);
	}
	
    public void publish(String method, JSONObject message) throws Exception {
        try (Gateway gateway = builder.connect()) {
            // Obtain channel
            Network network = gateway.getNetwork(channelName);
            // Obtain a smart contract deployed on the network.
            Contract contract = network.getContract(chaincodeName);
            // Create transaction
			Transaction transaction = contract.createTransaction(method);
			String id = UUID.randomUUID().toString();
			System.out.println("Generated id: "+id);
			int peersNumber = network.getChannel().getPeers().size();
            network.addCommitListener(this.getCommitTransactionListener(peersNumber, message), network.getChannel().getPeers(), transaction.getTransactionId());
            transaction.submit(id, message.getString(Utils.SUBJECT_KEY), message.getString(Utils.TOPIC_KEY), new Date().toString(), message.getString(Utils.MESSAGE_KEY));
        }
    }
    
    private CommitListener getCommitTransactionListener(int peersNumber, JSONObject jsonMessage) {
    	return new CommitListener() {
			@Override
			public void acceptDisconnect(PeerDisconnectEvent disconnectEvent) {
				// TODO Auto-generated method stub
			}
			
			@Override
			public void acceptCommit(TransactionEvent transactionEvent) {
				Integer callsNumber = Publisher.commitMap.get(transactionEvent.getTransactionID());
				if(callsNumber == null)
					Publisher.commitMap.put(transactionEvent.getTransactionID(), 1);
				else
					Publisher.commitMap.put(transactionEvent.getTransactionID(), callsNumber+1);
				if(Publisher.commitMap.get(transactionEvent.getTransactionID()) == peersNumber) {
					try {
						System.out.println("Publishing message "+jsonMessage.toString()+"...");
				    	ConnectionFactory connectionFactory = new ActiveMQConnectionFactory();
						Connection connection = connectionFactory.createConnection();
						Session session = connection.createSession(false, Session.AUTO_ACKNOWLEDGE);
						Destination destination = session.createTopic(jsonMessage.getString(Utils.TOPIC_KEY));
						MessageProducer producer = session.createProducer(destination);
						Message message = session.createTextMessage(jsonMessage.toString());
						producer.send(message);
						System.out.println("Message published.");
						connection.close();
					} catch(Exception e) {
						e.printStackTrace();
					}
				}
			}
		};
    }
}
