package it.tesi.maven.main;

import java.io.IOException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Date;
import java.util.HashMap;
import java.util.UUID;
import java.util.concurrent.TimeoutException;

import javax.jms.Connection;
import javax.jms.ConnectionFactory;
import javax.jms.Destination;
import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.MessageConsumer;
import javax.jms.Session;
import javax.jms.MessageListener;

import org.apache.activemq.ActiveMQConnectionFactory;
import org.apache.activemq.command.ActiveMQTextMessage;
import org.hyperledger.fabric.gateway.Contract;
import org.hyperledger.fabric.gateway.ContractException;
import org.hyperledger.fabric.gateway.Gateway;
import org.hyperledger.fabric.gateway.Network;
import org.hyperledger.fabric.gateway.Transaction;
import org.hyperledger.fabric.gateway.Wallet;
import org.hyperledger.fabric.gateway.Wallets;
import org.hyperledger.fabric.gateway.spi.CommitListener;
import org.hyperledger.fabric.gateway.spi.PeerDisconnectEvent;
import org.hyperledger.fabric.sdk.BlockEvent.TransactionEvent;
import org.json.JSONException;
import org.json.JSONObject;

public class Subscriber
{
	public static HashMap<String, Integer> commitMap = new HashMap<String, Integer>();
	private String connectionFilePath;
	private String channelName;
	private String chaincodeName;
	private Gateway.Builder builder;
	
	
	static {
		System.setProperty("org.hyperledger.fabric.sdk.service_discovery.as_localhost", "true");
	}
	
	public Subscriber(String connectionFilePath, String channelName, String chaincodeName) {
		this.connectionFilePath = connectionFilePath;
		this.channelName = channelName;
		this.chaincodeName = chaincodeName;
	}
	
	public void fabricConnect(String walletPath, String idFile) throws IOException {
		Path walletDirectory = Paths.get(walletPath);
        Wallet wallet = Wallets.newFileSystemWallet(walletDirectory);
        Path networkConfigFile = Paths.get(connectionFilePath);
        this.builder = Gateway.createBuilder()
        		.identity(wallet, idFile)
        		.networkConfig(networkConfigFile)
        		.discovery(true);
	}
	
	public void rerieveAllData() throws Exception{
		try (Gateway gateway = builder.connect()) {

            // Obtain a smart contract deployed on the network.
            Network network = gateway.getNetwork("mychannel");
            Contract contract = network.getContract("pubsub");
            byte[] result;
            
            //contract.submitTransaction("InitLedger");
			result = contract.evaluateTransaction("GetAllAssets");
			System.out.println(new String(result));
        } catch (ContractException e) { //| TimeoutException | InterruptedException e 
            e.printStackTrace();
        }
	}
	
	public void createListTopic(String id, String subject, String topic) throws Exception{
		try (Gateway gateway = builder.connect()) {

            // Obtain a smart contract deployed on the network.
            Network network = gateway.getNetwork("mychannel");
            Contract contract = network.getContract("pubsub");
            byte[] result;
            
            contract.submitTransaction("CreateAsset", id, subject, topic);
			result = contract.evaluateTransaction("GetAllAssets");
			System.out.println(new String(result));
        } catch (ContractException e) { //| TimeoutException | InterruptedException e 
            e.printStackTrace();
        }
	}
	
	public void assetExist(String id) throws Exception{
		try (Gateway gateway = builder.connect()) {

            // Obtain a smart contract deployed on the network.
            Network network = gateway.getNetwork("mychannel");
            Contract contract = network.getContract("pubsub");
            byte[] result;
            
            result =contract.evaluateTransaction("AssetExists", id);
			System.out.println(new String(result));
        } catch (ContractException e) { //| TimeoutException | InterruptedException e 
            e.printStackTrace();
        }
	}
	
	public void addTopic() throws Exception{
		try (Gateway gateway = builder.connect()) {

            // Obtain a smart contract deployed on the network.
            Network network = gateway.getNetwork("mychannel");
            Contract contract = network.getContract("pubsub");
            byte[] result;
            
            contract.submitTransaction("UpdateAsset", "ListaTopic", "Subscriber_1", "Topic_3");
			result = contract.evaluateTransaction("GetAllAssets");
			System.out.println(new String(result));
        } catch (ContractException e) { //| TimeoutException | InterruptedException e 
            e.printStackTrace();
        }
	}
	
	public void removeTopic() throws Exception{
		try (Gateway gateway = builder.connect()) {

            // Obtain a smart contract deployed on the network.
            Network network = gateway.getNetwork("mychannel");
            Contract contract = network.getContract("pubsub");
            byte[] result;
            
            contract.submitTransaction("RemoveTopic", "ListaTopic", "Subscriber_1", "Topic_2");
			result = contract.evaluateTransaction("GetAllAssets");
			System.out.println(new String(result));
        } catch (ContractException e) { //| TimeoutException | InterruptedException e 
            e.printStackTrace();
        }
	}
	
	
	
    public void subscribe(String method, JSONObject message) throws Exception {
        try (Gateway gateway = builder.connect()) {
            // Obtain a smart contract deployed on the network.
            Network network = gateway.getNetwork(channelName);
            Contract contract = network.getContract(chaincodeName);
			Transaction transaction = contract.createTransaction(method);
			String id = UUID.randomUUID().toString();
			System.out.println("Generated id: "+id);
			int peersNumber = network.getChannel().getPeers().size();
            network.addCommitListener(this.getCommitTransactionListener(peersNumber, message), network.getChannel().getPeers(), transaction.getTransactionId());
            transaction.submit(id, message.getString(Utils.SUBJECT_KEY), message.getString(Utils.TOPIC_KEY), new Date().toString());
        }
    }
    
    private CommitListener getCommitTransactionListener(int peersNumber, JSONObject jsonMessage) {
    	return new CommitListener() {
			
			@Override
			public void acceptDisconnect(PeerDisconnectEvent disconnectEvent) {
				// TODO Auto-generated method stub
			}
			
			@Override
			public void acceptCommit(TransactionEvent transactionEvent) {
				Integer callsNumber = Subscriber.commitMap.get(transactionEvent.getTransactionID());
				if(callsNumber == null)
					Subscriber.commitMap.put(transactionEvent.getTransactionID(), 1);
				else
					Subscriber.commitMap.put(transactionEvent.getTransactionID(), callsNumber+1);
				if(Subscriber.commitMap.get(transactionEvent.getTransactionID()) == peersNumber) {
					try {
						System.out.println("Instantiating Subscriber...");
				    	ConnectionFactory connectionFactory = new ActiveMQConnectionFactory();
						Connection connection = connectionFactory.createConnection();
						Session session = connection.createSession(false, Session.AUTO_ACKNOWLEDGE);
						Destination destination = session.createTopic(jsonMessage.getString(Utils.TOPIC_KEY));
						MessageConsumer consumer = session.createConsumer(destination);
						connection.start();
						System.out.println("Subscriber waiting for message...");
						//Message received = consumer.receive();
						consumer.setMessageListener(new MessageListener() {
							@Override
							public void onMessage(Message message) {
								// TODO Auto-generated method stub
								try {
									JSONObject jsonRecMessage = new JSONObject(((ActiveMQTextMessage) message).getText());
									System.out.println("Received message: " + jsonRecMessage.toString());
									System.out.println("Subscriber waiting for message...");
								} catch (JSONException | JMSException e) {
									// TODO Auto-generated catch block
									e.printStackTrace();
								}
							}
						});
						//JSONObject jsonRecMessage = new JSONObject(((ActiveMQTextMessage) received).getText());
						//System.out.println("Received message: " + jsonRecMessage.toString());
				    	//connection.close();
					} catch(Exception e) {
						e.printStackTrace();
					} 
				}
			}
		};
    }
}
