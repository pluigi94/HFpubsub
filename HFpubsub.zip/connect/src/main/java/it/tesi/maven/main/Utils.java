package it.tesi.maven.main;

import org.json.JSONObject;

import java.nio.file.Paths;
//import java.security.PrivateKey;
import java.util.Properties;
//import java.util.Set;

import org.hyperledger.fabric.gateway.Wallet;
import org.hyperledger.fabric.gateway.Wallets;
//import org.hyperledger.fabric.gateway.X509Identity;
import org.hyperledger.fabric.gateway.Identities;
import org.hyperledger.fabric.gateway.Identity;
import org.hyperledger.fabric.sdk.Enrollment;
//import org.hyperledger.fabric.sdk.User;
import org.hyperledger.fabric.sdk.security.CryptoSuite;
import org.hyperledger.fabric.sdk.security.CryptoSuiteFactory;
import org.hyperledger.fabric_ca.sdk.EnrollmentRequest;
import org.hyperledger.fabric_ca.sdk.HFCAClient;
//import org.hyperledger.fabric_ca.sdk.RegistrationRequest;

public class Utils {
	public static String CONNECTION_FILE = "/home/luigi/Scrivania/Esempi/fabric-samples/test-network/organizations/peerOrganizations/org1.example.com/connection-org1.yaml";
	public static String WALLET = "wallet";

	public static String CHANNEL = "mychannel";
	public static String CHAINCODE = "pubsub";
	public static String PUBLISH_METHOD = "PublishAsset";
	public static String SUBSCRIBE_METHOD = "SubscribeToTopic";
	
	public static String SUBJECT_KEY = "subject";
	public static String TOPIC_KEY = "topic";
	public static String MESSAGE_KEY = "message";
	
	private static String ADMIN_PEM_FILE = "/home/luigi/Scrivania/Esempi/fabric-samples/test-network/organizations/peerOrganizations/org1.example.com/ca/ca.org1.example.com-cert.pem";
	
	public static JSONObject createJSONMessage(String subject, String topic, String message) {
		JSONObject jsonMessage = new JSONObject();
		jsonMessage.put(SUBJECT_KEY, subject);
		jsonMessage.put(TOPIC_KEY, topic);
		jsonMessage.put(MESSAGE_KEY, message);
		return jsonMessage;
	}
	
	public static boolean enrollAdmin() throws Exception {
		Properties props = new Properties();
		props.put("pemFile", ADMIN_PEM_FILE);
		props.put("allowAllHostNames", "true");
		HFCAClient caClient = HFCAClient.createNewInstance("https://localhost:7054", props);
		CryptoSuite cryptoSuite = CryptoSuiteFactory.getDefault().getCryptoSuite();
		caClient.setCryptoSuite(cryptoSuite);
		// Create a wallet for managing identities
		Wallet wallet = Wallets.newFileSystemWallet(Paths.get(WALLET));

		// Check to see if we've already enrolled the admin user.
		if (wallet.get("admin") != null) 
			return false;

		// Enroll the admin user, and import the new identity into the wallet.
		final EnrollmentRequest enrollmentRequestTLS = new EnrollmentRequest();
		enrollmentRequestTLS.addHost("localhost");
		enrollmentRequestTLS.setProfile("tls");
		Enrollment enrollment = caClient.enroll("admin", "adminpw", enrollmentRequestTLS);
		Identity user = Identities.newX509Identity("Org1MSP", enrollment);
		wallet.put("admin", user);
		return true;
	}
}