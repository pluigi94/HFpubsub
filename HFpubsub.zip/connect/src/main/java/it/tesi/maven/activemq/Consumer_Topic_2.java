package it.tesi.maven.activemq;

import static java.lang.System.out;

import javax.jms.Connection;
import javax.jms.ConnectionFactory;
import javax.jms.Destination;
import javax.jms.Message;
import javax.jms.MessageConsumer;
import javax.jms.Session;
 
import org.apache.activemq.ActiveMQConnectionFactory;
import org.apache.activemq.command.ActiveMQTextMessage;
import org.json.JSONObject;
 
public class Consumer_Topic_2 {
 
	public static void main(String[] args) throws Exception {
		JSONObject documentObj = new JSONObject();
	  
		ConnectionFactory connFactory = new ActiveMQConnectionFactory();
 
		Connection conn = connFactory.createConnection();
 
		Session sess = conn.createSession(false, Session.AUTO_ACKNOWLEDGE);
 
		Destination dest = sess.createTopic("Topic_1");
 
		MessageConsumer cons = sess.createConsumer(dest);
 
		conn.start();
		
		Message msg = null;
		
		ActiveMQTextMessage textMessage = null;
	    
	    String msg_prod = null;
	    String msg_text = null;
 
		msg = cons.receive();
		
		textMessage = (ActiveMQTextMessage) msg;
		
		documentObj = new JSONObject(textMessage.getText());
    	msg_prod = documentObj.getString("Producer");
    	msg_text = documentObj.getString("Message");
 
    	out.print(msg_prod + ": ");
		out.println(msg_text);
 
		conn.close();
	}
 
}