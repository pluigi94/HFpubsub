package it.tesi.maven.activemq;

import static java.lang.System.out;

import javax.jms.Connection;
import javax.jms.ConnectionFactory;
import javax.jms.Destination;
import javax.jms.Message;
import javax.jms.MessageConsumer;
import javax.jms.Session;

import org.json.*;
 
import org.apache.activemq.ActiveMQConnectionFactory;
import org.apache.activemq.command.ActiveMQTextMessage;
 
public class Consumer_Queue {
	
	public static void main(String[] args) throws Exception {
		
		JSONObject documentObj = new JSONObject();
		
	    ConnectionFactory connFactory = new ActiveMQConnectionFactory();
	 
	    Connection conn = connFactory.createConnection();
	 
	    Session sess = conn.createSession(false, Session.AUTO_ACKNOWLEDGE);
	 
	    Destination dest = sess.createQueue("Queue_1");
	 
	    MessageConsumer cons = sess.createConsumer(dest);
	 
	    conn.start();
	    
	    Message msg = null;
	    
	    ActiveMQTextMessage textMessage = null;
	    
	    String msg_prod = null;
	    String msg_text = null;
	    
	    while(true) {
	    	msg = cons.receive();
	    	if(msg != null) {
	    		textMessage = (ActiveMQTextMessage) msg;
	    		if(textMessage.getText() != null) {
	    			documentObj = new JSONObject(textMessage.getText());
			    	msg_prod = documentObj.getString("Producer");
			    	msg_text = documentObj.getString("Message");
		    		out.print(msg_prod + ": ");
		    		out.println(msg_text);
	    		}else {
	    			out.println("nessun messaggio");
	    		}
	    	} else {
	    		conn.close();
	    		break;
	    	}
	    }
	  }
}