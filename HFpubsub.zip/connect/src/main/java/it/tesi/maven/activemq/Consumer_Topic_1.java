package it.tesi.maven.activemq;

import static java.lang.System.out;

import java.util.logging.Logger;

import javax.jms.Connection;
import javax.jms.ConnectionFactory;
import javax.jms.Destination;
import javax.jms.Message;
import javax.jms.MessageConsumer;
import javax.jms.Session;
 
import org.apache.activemq.ActiveMQConnectionFactory;
import org.apache.activemq.command.ActiveMQTextMessage;
import org.json.JSONObject;
 
public class Consumer_Topic_1 {
	private static final Logger logger = Logger.getLogger(Consumer_Topic_1.class.getName());
	
	public static void main(String[] args) throws Exception {
		JSONObject documentObj = new JSONObject();
		long start_1 = System.currentTimeMillis();
	  
		ConnectionFactory connFactory = new ActiveMQConnectionFactory();
 
		Connection conn = connFactory.createConnection();
 
		Session sess = conn.createSession(false, Session.AUTO_ACKNOWLEDGE);
 
		Destination dest = sess.createTopic("Topic_1");
 
		MessageConsumer cons = sess.createConsumer(dest);
		
		long finish_1 = System.currentTimeMillis();
		long misurazione_1 = finish_1 - start_1;
		logger.info("Tempo sottoscrizione: "  + misurazione_1);
 
		conn.start();
		
		Message msg = null;
		
		ActiveMQTextMessage textMessage = null;
	    
	    String msg_prod = null;
	    String msg_text = null;
 
	    while(true) {
	    	try {
	    		out.println("Attendo messaggio...");
	    		long start = System.currentTimeMillis();
	    		msg = cons.receive();
	    		//out.println(msg);
	    		long finish = System.currentTimeMillis();
				long misurazione = finish - start;
				logger.info("Tempo esecuzione ricezione messaggio: "  + misurazione);
				/*
				 * textMessage = (ActiveMQTextMessage) msg;
				 * 
				 * documentObj = new JSONObject(textMessage.getText()); msg_prod =
				 * documentObj.getString("Producer"); msg_text =
				 * documentObj.getString("Message");
				 * 
				 * out.print(msg_prod + ": "); out.println(msg_text);
				 */
	    	} catch(Exception e) {
	    		conn.close();
	    		break;
	    	}	
	    }
	}
}