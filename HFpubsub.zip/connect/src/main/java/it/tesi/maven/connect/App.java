package it.tesi.maven.connect;

import java.io.IOException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.concurrent.TimeoutException;
import org.hyperledger.fabric.gateway.Contract;
import org.hyperledger.fabric.gateway.ContractException;
import org.hyperledger.fabric.gateway.Gateway;
import org.hyperledger.fabric.gateway.Network;
import org.hyperledger.fabric.gateway.Wallet;
import org.hyperledger.fabric.gateway.Wallets;

public class App 
{
	static {
		System.setProperty("org.hyperledger.fabric.sdk.service_discovery.as_localhost", "true");
	}
	
    public static void main(String[] args) throws IOException {
        // Load an existing wallet holding identities used to access the network.
        Path walletDirectory = Paths.get("wallet");
        Wallet wallet = Wallets.newFileSystemWallet(walletDirectory);

        // Path to a common connection profile describing the network.
        Path networkConfigFile = Paths.get("/home/luigi/Scrivania/Esempi/fabric-samples/test-network/organizations/peerOrganizations/org1.example.com/connection-org1.yaml");

        // Configure the gateway connection used to access the network.
        Gateway.Builder builder = Gateway.createBuilder()
                .identity(wallet, "appUser")
                .networkConfig(networkConfigFile)
                .discovery(true);

        // Create a gateway connection
        try (Gateway gateway = builder.connect()) {

            // Obtain a smart contract deployed on the network.
            Network network = gateway.getNetwork("mychannel");
            Contract contract = network.getContract("pubsub");
            byte[] result;
            
			result = contract.evaluateTransaction("GetAllAssets");
			System.out.println(new String(result));
			
			contract.submitTransaction("InitLedger");
			result = contract.evaluateTransaction("GetAllAssets");
			System.out.println(new String(result));
			/*contract.submitTransaction("changeCarOwner", "CAR10", "Archie");
			result = contract.evaluateTransaction("queryCar", "CAR10");
			System.out.println(new String(result));
			*/
        } catch (ContractException | TimeoutException | InterruptedException e) { //| TimeoutException | InterruptedException e 
            e.printStackTrace();
        }
    }
}