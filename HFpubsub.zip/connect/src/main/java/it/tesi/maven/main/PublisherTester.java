package it.tesi.maven.main;

public class PublisherTester {
	public static void main(String[] args) throws Exception{
		Publisher publisher = new Publisher(Utils.CONNECTION_FILE, Utils.CHANNEL, Utils.CHAINCODE);
		publisher.fabricConnect(Utils.WALLET, "appUser");
		publisher.publish(Utils.PUBLISH_METHOD, Utils.createJSONMessage("Publisher_1", "Topic_1", "Hello World Luigi!"));
	}
}
