package it.tesi.maven.activemq;

import static java.lang.System.out;

import java.util.ArrayList;

import javax.jms.Connection;
import javax.jms.ConnectionFactory;
import javax.jms.Destination;
import javax.jms.Message;
import javax.jms.MessageConsumer;
import javax.jms.Session;
 
import org.apache.activemq.ActiveMQConnectionFactory;
//import org.apache.activemq.command.ActiveMQTextMessage;
import javax.jms.MessageListener;
//import org.json.JSONObject;

public class Consumer_Listener {
	
	public static void main(String[] args) throws Exception {
		//JSONObject documentObj = new JSONObject();
		  
		ConnectionFactory connFactory = new ActiveMQConnectionFactory();
		
		Connection conn = connFactory.createConnection();

		Session sess = conn.createSession(false, Session.AUTO_ACKNOWLEDGE);
		
		Destination dest = sess.createTopic("Topic_1");
		Destination dest2 = sess.createTopic("Topic_2");
		
		ArrayList<Destination> destinazioni = new ArrayList<Destination>();
		destinazioni.add(dest);
		destinazioni.add(dest2);
		
		Consumer luigi = new Consumer("Luigi", "001", destinazioni);
		
		//out.print(dest);
		
		
		for(int i = 0; i < luigi.getDestinazioni().size(); i++) {
			final Integer indice = i + 1;
			MessageConsumer consumer = sess.createConsumer(luigi.getDestinazioni().get(i));
			
			consumer.setMessageListener(new MessageListener() {
				
				@Override
				public void onMessage(Message message) {
					// TODO Auto-generated method stub
					out.println("Messaggio ricevuto dalla Topic " + indice);
				}
			});
		}
			
		/*
		 * MessageConsumer consumer_Topic1 = sess.createConsumer(dest); MessageConsumer
		 * consumer_Topic2 = sess.createConsumer(dest2);
		 * 
		 * consumer_Topic1.setMessageListener(new MessageListener() {
		 * 
		 * @Override public void onMessage(Message message) { // TODO Auto-generated
		 * method stub out.println("Messaggio ricevuto dalla Topic 1"); } });
		 * 
		 * consumer_Topic2.setMessageListener(new MessageListener() {
		 * 
		 * @Override public void onMessage(Message message) { // TODO Auto-generated
		 * method stub out.println("Messaggio ricevuto dalla Topic 2"); } });
		 */
		
		conn.start();
		
	
	}
}
