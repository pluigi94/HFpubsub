package it.tesi.maven.main;

public class SubscriberTester {
	public static void main(String[] args) throws Exception{
		Subscriber subscriber = new Subscriber(Utils.CONNECTION_FILE, Utils.CHANNEL, Utils.CHAINCODE);
		subscriber.fabricConnect(Utils.WALLET, "appUser");
		//subscriber.subscribe(Utils.SUBSCRIBE_METHOD, Utils.createJSONMessage("Subscriber_1", "Topic_1", ""));
		subscriber.assetExist("ListaTopic");
		//subscriber.createListTopic("ListaTopic", "Subscriber_1", "Topic_1");
		//subscriber.addTopic();
		//subscriber.removeTopic();
		//subscriber.rerieveAllData();
	}
}