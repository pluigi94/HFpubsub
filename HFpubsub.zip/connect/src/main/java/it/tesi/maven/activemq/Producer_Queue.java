package it.tesi.maven.activemq;

import static java.lang.System.out;

import javax.jms.Connection;
import javax.jms.ConnectionFactory;
import javax.jms.Destination;
import javax.jms.Message;
import javax.jms.MessageProducer;
import javax.jms.Session;
 
import org.apache.activemq.ActiveMQConnectionFactory;
import org.json.JSONObject;

public class Producer_Queue{
 
	public static void main(String[] args) throws Exception {
		
		JSONObject documentObj = new JSONObject();
	    
	    documentObj.put("Producer", "Mauro");
	    documentObj.put("Message", "Ciao Luigi sono Mauro");
	    
	    String message = documentObj.toString();
	    
	    try {
		    ConnectionFactory connFactory = new ActiveMQConnectionFactory();
		 
		    Connection conn = connFactory.createConnection();
		 
		    Session sess = conn.createSession(false, Session.AUTO_ACKNOWLEDGE);
		 
		    Destination dest = sess.createQueue("Queue_1");
		 
		    MessageProducer prod = sess.createProducer(dest);
		 
		    Message msg = sess.createTextMessage(message);
		 
		    prod.send(msg);
		 
		    conn.close(); 
		    
	    } catch (Exception e) {
	    	out.println("Errore nel producer");
	    }
	    
	    out.println("Il messaggio: " + message + " è stato inviato correttamente");
	    
	    
	    
	    //out.println("json" + documentObj);
	    
	  }
 
}