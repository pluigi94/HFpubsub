package com.blockchain.maven.pubsub;

import java.util.logging.Logger;

public class PublisherTester {
	
	private static final Logger logger = Logger.getLogger(PublisherTester.class.getName());
	
	
	public static void main(String[] args) throws Exception{
		FabricPubSub publisher = new FabricPubSub(Utils.HOST, Utils.WALLET, Utils.CONNECTION_FILE, Utils.CHANNEL, Utils.CHAINCODE);
		boolean adminEnrollment = publisher.enrollAdmin(Utils.ADMIN_PEM_FILE, Utils.ADMIN, Utils.ADMIN_PW, Utils.ADMIN_MSPID);
		// Admin Enrollment
		if(adminEnrollment)
			logger.info("Admin enrolled successfully.");
		else
			logger.info("Admin already enrolled.");
		// User Registration
		boolean userRegistration = publisher.register(Utils.ADMIN, Utils.ADMIN_PEM_FILE, Utils.PUB_IDENTITY, Utils.AFFILIATION, Utils.ADMIN_MSPID);
		if(userRegistration)
			logger.info("User "+Utils.PUB_IDENTITY+" registered and enrolled successfully.");
		else
			logger.info("User "+Utils.PUB_IDENTITY+" already registered.");
		
		// Connect to fabric blockchain
		publisher.connect(Utils.PUB_IDENTITY);
		// Publish message topic normal
		// publisher.publish(Utils.PUBLISH_METHOD, Utils.createJSONMessage(Utils.PUB_IDENTITY, Utils.TOPIC_1, Utils.FILLER_MESSAGE));
		// Publish message topic content based
		long start = System.currentTimeMillis();
		publisher.publish(Utils.PUBLISH_CONTENT_METHOD, Utils.createJSONMessage(Utils.PUB_IDENTITY, Utils.TOPIC_1, Utils.FILLER_MESSAGE));
		long finish = System.currentTimeMillis();
		long misurazione = finish - start;
		logger.info("Tempo esecuzione pubblicazione: "  + misurazione);
		//publisher.publish(Utils.PUBLISH_METHOD, Utils.createJSONMessageContentBased(Utils.PUB_IDENTITY, Utils.TOPIC_1, Utils.TOPIC_CONTENT_BASED, Utils.FILLER_MESSAGE));
		while(!publisher.isReady) {
			Thread.sleep(200);
		}
	}
}
