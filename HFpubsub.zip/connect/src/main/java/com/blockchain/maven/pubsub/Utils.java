package com.blockchain.maven.pubsub;

import org.json.JSONObject;

public class Utils {
	public static String ADMIN_PEM_FILE = "/home/luigi/Scrivania/Esempi/fabric-samples/test-network/organizations/peerOrganizations/org1.example.com/ca/ca.org1.example.com-cert.pem";
	public static String CONNECTION_FILE = "/home/luigi/Scrivania/Esempi/fabric-samples/test-network/organizations/peerOrganizations/org1.example.com/connection-org1.yaml";
	public static String WALLET = "wallet";

	public static String HOST = "https://localhost:7054";
	public static String CHANNEL = "mychannel";
	public static String CHAINCODE = "pubsub";
	
	public static String PUBLISH_METHOD = "PublishAsset";
	public static String PUBLISH_CONTENT_METHOD = "PublishAssetContent";
	public static String SUBSCRIBE_METHOD = "SubscribeToTopic";
	public static String RETRIEVE_BY_ID_METHOD = "ReadAsset";
	public static String RETRIEVE_TOPICS_BY_ID = "RetrieveTopics";
	public static String INIT_TOPIC_TABLE_METHOD = "InitTopicTable";
	public static String UPDATE_TOPIC_TABLE_METHOD = "UpdateTopicTable";
	public static String REMOVE_TOPIC_METHOD = "RemoveTopic";
	public static String ASSET_EXISTS_METHOD = "AssetExists";
	
	public static String ADMIN = "admin";
	public static String ADMIN_PW = "adminpw";
	public static String ADMIN_MSPID = "Org1MSP";
	public static String PUB_IDENTITY = "publisher";
	public static String SUB_IDENTITY = "subscriber";
	public static String AFFILIATION = "org1.department1";
	
	
	public static String TOPIC_KEY = "topic";
	public static String CONTENT_KEY = "content";
	public static String MESSAGE_KEY = "message";
	public static String SUBJECT_KEY = "subject";

	public static String FILLER_MESSAGE = "Hello World! Hello World! Hello World! Hello World! Hello World!";
	public static String EMPTY_MESSAGE = "";
	public static String TOPIC_1 = "Topic_1";
	public static String TOPIC_2 = "Topic_2";
	public static String TOPIC_3 = "Topic_3";
	public static String TOPIC_4 = "Topic_4";
	public static String TOPIC_5 = "Topic_5";
	public static String TOPIC_6 = "Topic_6";
	public static String TOPIC_7 = "Topic_7";
	public static String TOPIC_8 = "Topic_8";
	public static String TOPIC_9 = "Topic_9";
	public static String TOPIC_10 = "Topic_10";
	public static String TOPIC_CONTENT_BASED = "Sport";
	
	
	public static JSONObject createJSONMessage(String subject, String topic, String message) {
		JSONObject jsonMessage = new JSONObject();
		jsonMessage.put(SUBJECT_KEY, subject);
		jsonMessage.put(TOPIC_KEY, topic);
		jsonMessage.put(MESSAGE_KEY, message);
		return jsonMessage;
	}
	
	public static JSONObject createJSONMessageContentBased(String subject, String topic, String content, String message) {
		JSONObject jsonMessage = new JSONObject();
		jsonMessage.put(SUBJECT_KEY, subject);
		jsonMessage.put(TOPIC_KEY, topic);
		jsonMessage.put(CONTENT_KEY, content);
		jsonMessage.put(MESSAGE_KEY, message);
		return jsonMessage;
	}
}
