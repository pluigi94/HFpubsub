package com.blockchain.maven.pubsub;

import java.util.logging.Logger;

public class SubscriberTester {
private static final Logger logger = Logger.getLogger(PublisherTester.class.getName());
	
	public static void main(String[] args) throws Exception{
		FabricPubSub subscriber = new FabricPubSub(Utils.HOST, Utils.WALLET, Utils.CONNECTION_FILE, Utils.CHANNEL, Utils.CHAINCODE);
		boolean adminEnrollment = subscriber.enrollAdmin(Utils.ADMIN_PEM_FILE, Utils.ADMIN, Utils.ADMIN_PW, Utils.ADMIN_MSPID);
		// Admin Enrollment
		if(adminEnrollment)
			logger.info("Admin enrolled successfully.");
		else
			logger.info("Admin already enrolled.");
		// User Registration and enrollment
		boolean userRegistration = subscriber.register(Utils.ADMIN, Utils.ADMIN_PEM_FILE, Utils.SUB_IDENTITY, Utils.AFFILIATION, Utils.ADMIN_MSPID);
		if(userRegistration)
			logger.info("User "+Utils.SUB_IDENTITY+" registered and enrolled successfully.");
		else
			logger.info("User "+Utils.SUB_IDENTITY+" already registered.");
		
		// Connect to fabric blockchain
		subscriber.connect(Utils.SUB_IDENTITY);
		
		// Check if topics table exists
		if(subscriber.assetExist(Utils.ASSET_EXISTS_METHOD, Utils.SUB_IDENTITY)) {
			String topicTable = subscriber.retrieveById(Utils.RETRIEVE_BY_ID_METHOD, Utils.SUB_IDENTITY);
			String topics = subscriber.retrieveTopics(Utils.RETRIEVE_TOPICS_BY_ID, Utils.SUB_IDENTITY);
			logger.info("Struttura topics già esistente: " + topics);
		} else {
			// init topic table
			subscriber.initTopicTable(Utils.INIT_TOPIC_TABLE_METHOD, Utils.SUB_IDENTITY);
			String topics = subscriber.retrieveTopics(Utils.RETRIEVE_TOPICS_BY_ID, Utils.SUB_IDENTITY);
		}

		// Subscribe to topic
		long start = System.currentTimeMillis();
		subscriber.subscribe(Utils.SUBSCRIBE_METHOD, Utils.createJSONMessage(Utils.SUB_IDENTITY, Utils.TOPIC_5, Utils.EMPTY_MESSAGE), Utils.UPDATE_TOPIC_TABLE_METHOD, new SubscriberInterface() {
			@Override
			public void receive(String id) {
				try {
					long start_receive = System.currentTimeMillis();
					String fullMessage = subscriber.retrieveById(Utils.RETRIEVE_BY_ID_METHOD, id);
					long finish_receive = System.currentTimeMillis();
					long misurazione_receive = finish_receive - start_receive;
					logger.info("Tempo esecuzione ricezione messaggio: "  + misurazione_receive);
					logger.info("Retrieved Message: "+fullMessage);
					logger.info("Subscriber waiting for message..."); 
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
		long finish = System.currentTimeMillis();
		long misurazione = finish - start;
		logger.info("Tempo esecuzione sottoscrizione: "  + misurazione);
		
		while(true) {
			Thread.sleep(200);
		}
	}
}