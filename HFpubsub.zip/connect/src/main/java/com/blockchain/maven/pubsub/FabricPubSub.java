package com.blockchain.maven.pubsub;

import static java.lang.System.out;

import java.io.IOException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.security.PrivateKey;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Properties;
import java.util.Set;
import java.util.UUID;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.jms.Connection;
import javax.jms.Destination;
import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.MessageConsumer;
import javax.jms.MessageListener;
import javax.jms.MessageProducer;
import javax.jms.Session;

import org.apache.activemq.ActiveMQConnectionFactory;
import org.apache.activemq.command.ActiveMQTextMessage;
import org.hyperledger.fabric.gateway.Contract;
import org.hyperledger.fabric.gateway.Gateway;
import org.hyperledger.fabric.gateway.Identities;
import org.hyperledger.fabric.gateway.Identity;
import org.hyperledger.fabric.gateway.Network;
import org.hyperledger.fabric.gateway.Transaction;
import org.hyperledger.fabric.gateway.Wallet;
import org.hyperledger.fabric.gateway.Wallets;
import org.hyperledger.fabric.gateway.X509Identity;
import org.hyperledger.fabric.gateway.spi.CommitListener;
import org.hyperledger.fabric.gateway.spi.PeerDisconnectEvent;
import org.hyperledger.fabric.sdk.Enrollment;
import org.hyperledger.fabric.sdk.User;
import org.hyperledger.fabric.sdk.BlockEvent.TransactionEvent;
import org.hyperledger.fabric.sdk.security.CryptoSuite;
import org.hyperledger.fabric.sdk.security.CryptoSuiteFactory;
import org.hyperledger.fabric_ca.sdk.EnrollmentRequest;
import org.hyperledger.fabric_ca.sdk.HFCAClient;
import org.hyperledger.fabric_ca.sdk.RegistrationRequest;
import org.json.JSONObject;

public class FabricPubSub extends Thread {
	public HashMap<String, Integer> commitMap = new HashMap<String, Integer>();

	public boolean isReady = false;
	private static final Logger logger = Logger.getLogger(FabricPubSub.class.getName());

	private String host;
	private String wallet;
	private String connectionFilePath;
	private String channelName;
	private String chaincodeName;
	private Gateway.Builder builder;

	static {
		System.setProperty("org.hyperledger.fabric.sdk.service_discovery.as_localhost", "true");
	}

	public FabricPubSub(String host, String wallet, String connectionFilePath, String channelName,
			String chaincodeName) {
		this.host = host;
		this.wallet = wallet;
		this.connectionFilePath = connectionFilePath;
		this.channelName = channelName;
		this.chaincodeName = chaincodeName;
	}

	public boolean register(String admin, String adminPemFile, String userIdentity, String affiliation, String mspId)
			throws Exception {
		Wallet wallet = Wallets.newFileSystemWallet(Paths.get(this.wallet));
		X509Identity adminIdentity = (X509Identity) wallet.get(admin);
		if ((wallet.get(userIdentity) != null) || (adminIdentity == null))
			return false;

		HFCAClient caClient = this.createCAClient(adminPemFile);
		// Register the user, enroll the user, and import the new identity into the
		// wallet.
		RegistrationRequest registrationRequest = new RegistrationRequest(userIdentity);
		registrationRequest.setAffiliation(affiliation);
		registrationRequest.setEnrollmentID(userIdentity);
		String enrollmentSecret = caClient.register(registrationRequest,
				this.getAdminAsUser(adminIdentity, admin, affiliation, mspId));
		caClient.enroll(userIdentity, enrollmentSecret);
		Identity user = Identities.newX509Identity(mspId, adminIdentity.getCertificate(),
				adminIdentity.getPrivateKey());
		wallet.put(userIdentity, user);
		return true;
	}

	public boolean enrollAdmin(String adminPemFile, String admin, String password, String mspId) throws Exception {
		HFCAClient caClient = this.createCAClient(adminPemFile);
		// Create a wallet for managing identities
		Wallet wallet = Wallets.newFileSystemWallet(Paths.get(this.wallet));
		// Check to see if we've already enrolled the admin user.
		if (wallet.get(admin) != null)
			return false;

		// Enroll the admin user, and import the new identity into the wallet.
		final EnrollmentRequest enrollmentRequestTLS = new EnrollmentRequest();
		enrollmentRequestTLS.addHost("localhost");
		enrollmentRequestTLS.setProfile("tls");
		Enrollment enrollment = caClient.enroll(admin, password, enrollmentRequestTLS);
		Identity user = Identities.newX509Identity(mspId, enrollment);
		wallet.put(admin, user);
		return true;
	}

	private HFCAClient createCAClient(String pemFile) throws Exception {
		// Create a CA client for interacting with the CA.
		Properties props = new Properties();
		props.put("pemFile", pemFile);
		props.put("allowAllHostNames", "true");
		HFCAClient caClient = HFCAClient.createNewInstance(this.host, props);
		CryptoSuite cryptoSuite = CryptoSuiteFactory.getDefault().getCryptoSuite();
		caClient.setCryptoSuite(cryptoSuite);
		return caClient;
	}

	private User getAdminAsUser(X509Identity adminIdentity, String name, String affiliation, String mspId) {
		User admin = new User() {
			@Override
			public String getName() {
				return name;
			}

			@Override
			public Set<String> getRoles() {
				return null;
			}

			@Override
			public String getAccount() {
				return null;
			}

			@Override
			public String getAffiliation() {
				return affiliation;
			}

			@Override
			public Enrollment getEnrollment() {
				return new Enrollment() {
					@Override
					public PrivateKey getKey() {
						return adminIdentity.getPrivateKey();
					}

					@Override
					public String getCert() {
						return Identities.toPemString(adminIdentity.getCertificate());
					}
				};
			}

			@Override
			public String getMspId() {
				return mspId;
			}
		};

		return admin;
	}

	public void connect(String idFile) throws IOException {
		Path walletDirectory = Paths.get(this.wallet);
		Wallet wallet = Wallets.newFileSystemWallet(walletDirectory);
		Path networkConfigFile = Paths.get(connectionFilePath);
		this.builder = Gateway.createBuilder().identity(wallet, idFile).networkConfig(networkConfigFile)
				.discovery(true);
	}

	public void publish(String method, JSONObject message) throws Exception {
		this.isReady = false;
		Gateway gateway = builder.connect();
		// Obtain channel
		Network network = gateway.getNetwork(channelName);
		// Obtain a smart contract deployed on the network.
		Contract contract = network.getContract(chaincodeName);
		// Create transaction
		Transaction transaction = contract.createTransaction(method);
		String id = UUID.randomUUID().toString();
		logger.log(Level.INFO, "Generated id: " + id);
		network.addCommitListener(this.getPublisherCommitListener(message.getString(Utils.TOPIC_KEY), id),
				network.getChannel().getPeers(), transaction.getTransactionId());
		transaction.submit(id, message.getString(Utils.SUBJECT_KEY), message.getString(Utils.TOPIC_KEY), "Sport", new Date().toString(), message.getString(Utils.MESSAGE_KEY));
	}

	public void subscribe(String method, JSONObject message, String updateMethod, SubscriberInterface subscriber)
			throws Exception {
		this.isReady = false;
		Gateway gateway = builder.connect();
		Network network = gateway.getNetwork(channelName);
		Contract contract = network.getContract(chaincodeName);
		Transaction transaction = contract.createTransaction(method);
		String id = UUID.randomUUID().toString();
		logger.log(Level.INFO, "Generated id: " + id);
		network.addCommitListener(this.getSubscriberCommitListener(subscriber, message, updateMethod),
				network.getChannel().getPeers(), transaction.getTransactionId());
		transaction.submit(id, message.getString(Utils.SUBJECT_KEY), message.getString(Utils.TOPIC_KEY),
				new Date().toString());
	}

	public String retrieveById(String method, String id) throws Exception {
		Gateway gateway = builder.connect();
		Network network = gateway.getNetwork(channelName);
		Contract contract = network.getContract(chaincodeName);
		Transaction transaction = contract.createTransaction(method);
		return new String(transaction.submit(id));
	}

	public String retrieveTopics(String method, String id) throws Exception {
		Gateway gateway = builder.connect();
		Network network = gateway.getNetwork(channelName);
		Contract contract = network.getContract(chaincodeName);
		Transaction transaction = contract.createTransaction(method);
		return new String(transaction.submit(id));
	}

	public void initTopicTable(String method, String id) throws Exception {
		Gateway gateway = builder.connect();
		Network network = gateway.getNetwork(this.channelName);
		Contract contract = network.getContract(this.chaincodeName);
		contract.submitTransaction(method, id);
		byte[] result = contract.evaluateTransaction("GetAllAssets");
		logger.info("All Assets: " + new String(result));
	}

	public void updateTopicTable(String method, String id, String topic) throws Exception {
		Gateway gateway = builder.connect();
		Network network = gateway.getNetwork(this.channelName);
		Contract contract = network.getContract(this.chaincodeName);
		contract.submitTransaction(method, id, topic);
		byte[] result = contract.evaluateTransaction("GetAllAssets");
		logger.info("All Assets: " + new String(result));
	}

	public void removeTopic(String method, String id, String topic) throws Exception {
		Gateway gateway = builder.connect();
		Network network = gateway.getNetwork(this.channelName);
		Contract contract = network.getContract(this.chaincodeName);
		contract.submitTransaction(method, id, topic);
		byte[] result = contract.evaluateTransaction("GetAllAssets");
		logger.info("All Assets: " + new String(result));
	}

	public boolean assetExist(String method, String id) throws Exception {
		Gateway gateway = builder.connect();
		Network network = gateway.getNetwork(this.channelName);
		Contract contract = network.getContract(this.chaincodeName);
		byte[] result = contract.evaluateTransaction(method, id);
		return Boolean.parseBoolean(new String(result));
	}

	private CommitListener getPublisherCommitListener(String topic, String uuid) {
		FabricPubSub parent = this;
		return new CommitListener() {
			@Override
			public void acceptDisconnect(PeerDisconnectEvent disconnectEvent) {
				// TODO Auto-generated method stub
			}

			@Override
			public void acceptCommit(TransactionEvent transactionEvent) {
				Integer callsNumber = commitMap.get(transactionEvent.getTransactionID());
				if (callsNumber == null)
					commitMap.put(transactionEvent.getTransactionID(), 1);
				else
					commitMap.put(transactionEvent.getTransactionID(), callsNumber + 1);

				if (commitMap.get(transactionEvent.getTransactionID()) == 1) {
					try {
						logger.info("Publishing message to topic " + topic + "...");
						Connection connection = new ActiveMQConnectionFactory().createConnection();
						Session session = connection.createSession(false, Session.AUTO_ACKNOWLEDGE);
						Destination destination = session.createTopic(topic);
						MessageProducer producer = session.createProducer(destination);
						Message message = session.createTextMessage(uuid);
						producer.send(message);
						logger.info("Message published.");
						connection.close();
						parent.isReady = true;
					} catch (Exception e) {
						logger.severe("Error occurred");
						e.printStackTrace();
					}
				}
			}
		};
	}

	private CommitListener getSubscriberCommitListener(SubscriberInterface subscriber, JSONObject jsonMessage,
			String updateMethod) {
		FabricPubSub parent = this;
		return new CommitListener() {

			@Override
			public void acceptDisconnect(PeerDisconnectEvent disconnectEvent) {
				// TODO Auto-generated method stub
			}

			@Override
			public void acceptCommit(TransactionEvent transactionEvent) {
				Integer callsNumber = commitMap.get(transactionEvent.getTransactionID());
				if (callsNumber == null)
					commitMap.put(transactionEvent.getTransactionID(), 1);
				else
					commitMap.put(transactionEvent.getTransactionID(), callsNumber + 1);

				if (commitMap.get(transactionEvent.getTransactionID()) == 1) {
					try {
						parent.updateTopicTable(updateMethod, jsonMessage.getString(Utils.SUBJECT_KEY),
								jsonMessage.getString(Utils.TOPIC_KEY));
						String topics = parent.retrieveTopics(Utils.RETRIEVE_TOPICS_BY_ID, jsonMessage.getString(Utils.SUBJECT_KEY));
						logger.info("Instantiating Subscriber...");
						logger.info("Subscriber waiting for message..."); 
						/*
						 * Connection connection = new ActiveMQConnectionFactory().createConnection();
						 * Session session = connection.createSession(false, Session.AUTO_ACKNOWLEDGE);
						 * Destination destination =
						 * session.createTopic(jsonMessage.getString(Utils.TOPIC_KEY)); MessageConsumer
						 * consumer = session.createConsumer(destination);
						 */
						parent.messageListener(topics, subscriber);
						//connection.start();
						
						/*
						 * ActiveMQTextMessage receivedMessage = (ActiveMQTextMessage)
						 * consumer.receive(); logger.info("Received message: " +
						 * receivedMessage.getText()); subscriber.receive(receivedMessage.getText());
						 * connection.close();
						 */
						 
					} catch (Exception e) {
						logger.severe("Error occurred");
						e.printStackTrace();
					}
				}
			}
		};
	}

	public void messageListener(String topics,SubscriberInterface sub) throws JMSException {
		ArrayList<String> listTopic = new ArrayList<String>();
		topics = topics.replace("[", "");
		topics = topics.replace("]", "");
		topics = topics.replace(",", "");
		String flag = "end";
		StringBuilder topic = new StringBuilder();
		for(int i = 0; i < topics.length(); i++) {
			if(topics.charAt(i) == '"') {
				if(flag == "end") {
					flag = "start";
				} else {
					flag = "end";
					listTopic.add(topic.toString());
					topic = new StringBuilder();
				}
			}
			if(topics.charAt(i) != '"' && flag == "start") {
				topic.append(topics.charAt(i));
			}
		}
		
		Connection connection = new ActiveMQConnectionFactory().createConnection();
		Destination dest = null;
		MessageConsumer consumer = null;
		Session session = connection.createSession(false, Session.AUTO_ACKNOWLEDGE);
		
		for(int i = 0; i < listTopic.size(); i++) {
			final Integer indice = i;
			dest = session.createTopic(listTopic.get(i));
			consumer = session.createConsumer(dest);
			consumer.setMessageListener(new MessageListener() {
				@Override
				public void onMessage(Message message) {
					ActiveMQTextMessage receivedMessage = (ActiveMQTextMessage) message;
					logger.info("Messaggio ricevuto dalla Topic: " + listTopic.get(indice));
					try {
						logger.info("Received message: " + receivedMessage.getText());
						sub.receive(receivedMessage.getText());
					} catch (JMSException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
			});
		}
		connection.start();
	}
}
