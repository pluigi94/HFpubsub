package com.blockchain.maven.pubsub;

public interface SubscriberInterface {
	void receive(String id);
}
